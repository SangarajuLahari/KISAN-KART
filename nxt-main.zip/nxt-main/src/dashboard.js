import React from 'react';
import Layout from '../src/components/layout/layout.js';
const Dashboard=()=>{
    return(
        <Layout>
            <h1>Dashboard page</h1>
        </Layout>
    );
};
export default Dashboard;